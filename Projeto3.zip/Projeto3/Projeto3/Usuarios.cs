﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto3
{
    class Usuarios
    {
        private int id;
        private string nome;
        private string senha;
        private string cpf;

        public int Id
        {
            get { return id; }
            set { id = value; }
        }
        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }

        public string Senha
        {
            get { return senha; }
            set { senha = value; }
        }

        public string Cpf
        {
            get { return cpf; }
            set { cpf = value; }
        }


        public bool CadastrarUsuario()
        {
            try
            {
                using (MySqlConnection conexao = new BancoDB().conectar())
                {

                    string inserir = "insert into usuarios (nome, senha, cpf) values (@nome, @senha, @cpf)";

                    MySqlCommand comando = new MySqlCommand(inserir, conexao);

                    comando.Parameters.AddWithValue("@nome", Nome);
                    comando.Parameters.AddWithValue("@senha", Senha);
                    comando.Parameters.AddWithValue("@cpf", Cpf);

                    int resultado = Convert.ToInt32(comando.ExecuteNonQuery());
                    if(resultado > 0)
                    { 
                        return true;
                    }
                    else
                    {
                        MessageBox.Show("falha ao cadastrar usuario");
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao cadastrar usuario" + ex.Message);
                return false;
            }
        }

        public bool Logar()
        {
            try
            {
                using (MySqlConnection conexao = new BancoDB().conectar())
                {

                    string query = "select id from usuarios where nome = @nome and senha = @senha and cpf = @cpf";

                    MySqlCommand comando = new MySqlCommand(query, conexao);

                    comando.Parameters.AddWithValue("@nome", nome);
                    comando.Parameters.AddWithValue("@senha", senha);
                    comando.Parameters.AddWithValue("@cpf", cpf);
                    

                    int resultado = Convert.ToInt32(comando.ExecuteScalar());
                    if (resultado > 0)
                    {
                        id = resultado;
                        return true;
                    }
                    else
                    {
                      return false;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao logar usuario" + ex.Message);
                return false;
            }
        }

    }
}
