using System.Security.Cryptography.X509Certificates;

namespace Projeto3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void lklLogin_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Tela_Login tela_Login = new Tela_Login();
            tela_Login.Show();
            this.Hide();
        }

        private void btnCadastro_Click(object sender, EventArgs e)
        {
            try
            {
                Usuarios usuarios = new Usuarios();

                usuarios.Nome = txtNome.Text;
                usuarios.Senha = txtSenha.Text;
                usuarios.Cpf = txtCpf.Text;

                bool cadastro = usuarios.CadastrarUsuario();

                if (!txtNome.Equals("") && !txtSenha.Equals("") && !txtCpf.Equals(""))
                {
                    if (cadastro)
                    {
                        MessageBox.Show("Cadastro realizado com sucesso!!");
                        Tela_Tarefa tela_tarefa = new Tela_Tarefa();
                        tela_tarefa.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Erro ao realizar cadastro");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro no cath para cadastrar usuario");
            }

        }
    }
}
