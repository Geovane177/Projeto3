﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto3
{
    public partial class Tela_Tarefa : Form
    {
        public Tela_Tarefa()
        {
            InitializeComponent();
        }

        private void btnAdicionar_Click(object sender, EventArgs e)
        {
            try
            {
                Tarefas tarefas = new Tarefas();
                tarefas.Titulo = txtTitulo.Text;
                tarefas.Descricao = txtDescricao.Text;
                tarefas.Estado = txtEstado.Text;

                bool adicionar = tarefas.adicionar();

                if (!txtTitulo.Equals("") && !txtDescricao.Equals("") && !txtEstado.Equals(""))
                {
                    if (adicionar)
                    {
                        MessageBox.Show("Tarefa adicionado com sucesso");
                    }
                    else
                    {
                        MessageBox.Show("Erro ao adicionar Tarefa");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro no catch de adicionar!");
            }
        }

        private void Tela_Tarefa_Load(object sender, EventArgs e)
        {
            Tarefas tarefas = new Tarefas();
            tarefas.ListarTarefas(dvgTarefa);
        }
    }
}
