﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto3
{
    public partial class Tela_Login : Form
    {
        public Tela_Login()
        {
            InitializeComponent();
        }

        private void lklCadastro_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                Usuarios usuarios = new Usuarios();

                usuarios.Nome = txtNome.Text;
                usuarios.Senha = txtSenha.Text;
                usuarios.Cpf = txtCpf.Text;


                bool login = usuarios.Logar();

                if (!txtNome.Equals("") && !txtSenha.Equals("") && !txtCpf.Equals(""))
                {
                    if (login)
                    {
                        MessageBox.Show("Login realizado com sucesso!!");
                        Tela_Tarefa tela_Tarefa = new Tela_Tarefa();
                        tela_Tarefa.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Erro ao realizar login");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro no cath para logar usuario");
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
