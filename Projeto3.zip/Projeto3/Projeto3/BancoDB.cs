﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace Projeto3
{
    class BancoDB
    {
        private string ConexaoBanco = "server=localhost; database=tarefasDB; Uid=root; Pwd=";

        public MySqlConnection conectar()
        {
            MySqlConnection conexao = new MySqlConnection(ConexaoBanco);
            conexao.Open();
            return conexao;
        }
    }
}
