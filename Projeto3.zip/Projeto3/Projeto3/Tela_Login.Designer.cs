﻿namespace Projeto3
{
    partial class Tela_Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            lklCadastro = new LinkLabel();
            label2 = new Label();
            label3 = new Label();
            txtNome = new TextBox();
            txtSenha = new TextBox();
            btnLogin = new Button();
            label4 = new Label();
            txtCpf = new TextBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial Black", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(340, 84);
            label1.Name = "label1";
            label1.Size = new Size(100, 33);
            label1.TabIndex = 0;
            label1.Text = "LOGIN";
            // 
            // lklCadastro
            // 
            lklCadastro.AutoSize = true;
            lklCadastro.Location = new Point(317, 306);
            lklCadastro.Name = "lklCadastro";
            lklCadastro.Size = new Size(194, 15);
            lklCadastro.TabIndex = 1;
            lklCadastro.TabStop = true;
            lklCadastro.Text = "Não possui uma conta? cadastre-se";
            lklCadastro.LinkClicked += lklCadastro_LinkClicked;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(261, 145);
            label2.Name = "label2";
            label2.Size = new Size(40, 15);
            label2.TabIndex = 2;
            label2.Text = "Nome";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(261, 193);
            label3.Name = "label3";
            label3.Size = new Size(39, 15);
            label3.TabIndex = 3;
            label3.Text = "Senha";
            // 
            // txtNome
            // 
            txtNome.Location = new Point(340, 137);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(135, 23);
            txtNome.TabIndex = 4;
            // 
            // txtSenha
            // 
            txtSenha.Location = new Point(340, 185);
            txtSenha.Name = "txtSenha";
            txtSenha.Size = new Size(135, 23);
            txtSenha.TabIndex = 5;
            // 
            // btnLogin
            // 
            btnLogin.Location = new Point(376, 271);
            btnLogin.Name = "btnLogin";
            btnLogin.Size = new Size(75, 23);
            btnLogin.TabIndex = 6;
            btnLogin.Text = "Logar";
            btnLogin.UseVisualStyleBackColor = true;
            btnLogin.Click += btnLogin_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(261, 238);
            label4.Name = "label4";
            label4.Size = new Size(26, 15);
            label4.TabIndex = 7;
            label4.Text = "Cpf";
            // 
            // txtCpf
            // 
            txtCpf.Location = new Point(340, 230);
            txtCpf.Name = "txtCpf";
            txtCpf.Size = new Size(135, 23);
            txtCpf.TabIndex = 8;
            // 
            // Tela_Login
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(txtCpf);
            Controls.Add(label4);
            Controls.Add(btnLogin);
            Controls.Add(txtSenha);
            Controls.Add(txtNome);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(lklCadastro);
            Controls.Add(label1);
            Name = "Tela_Login";
            Text = "Tela_Login";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private LinkLabel lklCadastro;
        private Label label2;
        private Label label3;
        private TextBox txtNome;
        private TextBox txtSenha;
        private Button btnLogin;
        private Label label4;
        private TextBox txtCpf;
    }
}