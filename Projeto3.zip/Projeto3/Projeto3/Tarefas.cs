﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto3
{
    class Tarefas
    {
        private string titulo;
        private string descricao;
        private string estado;

        public string Titulo
        {
            get { return titulo; }
            set { titulo = value; }
        }

        public string Descricao
        {
            get { return descricao; }
            set { descricao = value; }
        }

        public string Estado
        {
            get { return estado; }
            set { estado = value; }
        }

        public bool adicionar()
        {
            try
            {
                using (MySqlConnection conexao = new BancoDB().conectar())
                {

                    string inserir = "insert into tarefas (titulo, descricao, estado, usuario_id) values (@titulo, @descricao, @estado, @usuario_id)";

                    MySqlCommand comando = new MySqlCommand(inserir, conexao);
                    Usuarios usuarios = new Usuarios();

                    comando.Parameters.AddWithValue("@titulo", titulo);
                    comando.Parameters.AddWithValue("@descricao", descricao);
                    comando.Parameters.AddWithValue("@estado", estado);
                    comando.Parameters.AddWithValue("@usuario_id", usuarios.Id);

                    int resultado = Convert.ToInt32(comando.ExecuteNonQuery());
                    if (resultado > 0)
                    {
                        return true;
                    }
                    else
                    {
                        MessageBox.Show("falha ao adicionar tarefa");
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro no catch ao adicionar tarefa!" + ex.Message);
                return false;
            }
        }
        public bool ListarTarefas(DataGridView DataGrid)
        {
            try {
                using (MySqlConnection conexao = new BancoDB().conectar())
                {
                    string query = "select * from usuarios";

                    MySqlCommand comando = new MySqlCommand(query, conexao);
                    MySqlDataAdapter adapter = new MySqlDataAdapter(comando);
                    DataTable tabela = new DataTable();
                    adapter.Fill(tabela);
                    DataGrid.DataSource = tabela;

                    if (DataGrid.Rows.Count > 0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                

            }
            catch(Exception ex)
            {
                MessageBox.Show("Erro no catch listar"+ ex.Message);
                return false;
            }
        }

    }
}
